import React from 'react'
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
const Details = () => {
    const [show, setShow] = useState([])
    let {name} = useParams()
    useEffect(() => {
         
        axios.get(`https://newsapi.org/v2/top-headlines?country=${name}&apiKey=1b388a986a244148a818b9db8f4a1c01`)
          .then(res => {
            console.log(res.data);
            setShow(res.data.articles)
          });
    }, [])
  return (
    <>
    <h1>{show.source.id}</h1>
    <h3>{show.title}</h3>
    <p>{show.description}</p>
    </>
  )
}

export default Details