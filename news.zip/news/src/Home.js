import React from 'react'
import axios from "axios";
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useParams } from 'react-router-dom';
const Home = () => {
    const [post, setPost] = useState([])
    let {id} = useParams()
    console.log(id);
    useEffect(() => {
         
        axios.get(`https://newsapi.org/v2/top-headlines?country=us&apiKey=1b388a986a244148a818b9db8f4a1c01`)
          .then(res => {
            console.log(res.data);
            setPost(res.data.articles)
          });
    }, [])
    
  return (
    <>
    <div className="container"> 
    {
        post.map((a)=> (
          <> 
          <img src={a.urlToImage} alt="" />
            <h1><Link to={`/details/${a.source.id}`}>{a.title}</Link></h1>
          </>
        ))
    }
    </div>
    </>
  )
}

export default Home