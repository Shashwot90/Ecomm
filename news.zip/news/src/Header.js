import React from 'react'
import { Routes, Route, Link } from "react-router-dom";
import Home from './Home';
import Details from './Details';
const Header = () => {
  return (
    <>
        <header className='text-center'>
            <h1>The Blog</h1>
        <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/details/:id" element={<Details />} />
        </Routes>
        </header>
    </>
  )
}

export default Header