$(document).ready(function () {
    $(".four").owlCarousel({
        items: 4,
        margin: 30,
    });
    $(".five").owlCarousel({
        items: 5,
        margin: 30,
    });
});