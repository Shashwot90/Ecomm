import React from 'react'

const Services = (props) => {
  return (
    <div className='box'>
      <h2>{props.title}</h2>
      <p>{props.des}</p>
    </div>
  )
}

export default Services
