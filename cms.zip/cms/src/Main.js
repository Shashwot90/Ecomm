import Header from "./Header"
import Footer from "./Footer"
import Services from "./Services"
import "./Style.css"
function Main() {
    return( 
        <>
            <h1>this is website</h1>
            <Header/> 
            <div className="flex">
            <Services title="Web Services" des="Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores, ratione?"/>
            <Services title="SEO Services" des="Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores, ratione?"/>
            <Services title="PHP Services" des="Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores, ratione?"/>
            </div>
             
            <Footer />
        </>
    )
}
export default Main