import React from 'react'

const Footer = () => {
  return (
    <footer>
      <h3>this is footer</h3>
    </footer>
  )
}

export default Footer
