import React from 'react';
import ReactDOM from 'react-dom/client';
import Main from './Main';
var a = <h1>Sajan</h1>
ReactDOM.createRoot(document.getElementById('root')).render(<Main />)
