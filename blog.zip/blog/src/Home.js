import React from 'react'
import axios from "axios";
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
const Home = () => {
    const [post, setPost] = useState([])
    useEffect(() => {
         
        axios.get(`https://jsonplaceholder.typicode.com/posts`)
          .then(res => {
            console.log(res.data);
            setPost(res.data)
          });
    }, [])
    
  return (
    <>
    <div className="container"> 
    {
        post.map((a)=> (
            <h1><Link to={`/details/${a.id}`}>{a.title}</Link></h1>
        ))
    }
    </div>
    </>
  )
}

export default Home