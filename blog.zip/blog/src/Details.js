import React from 'react'
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
const Details = () => {
    const [show, setShow] = useState([])
    let {id} = useParams()
    useEffect(() => {
         
        axios.get(`https://jsonplaceholder.typicode.com/posts/${id}`)
          .then(res => {
            console.log(res.data);
            setShow(res.data)
          });
    }, [])
  return (
    <>
    <h1>{show.title}</h1>
    <p>{show.body}</p>
    </>
  )
}

export default Details