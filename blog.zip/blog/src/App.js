import logo from './logo.svg';
import './App.css';
import Home from './Home';
import Header from './Header'
function App() {
  return (
    <>
      <Header />
      
    </>
  );
}

export default App;
